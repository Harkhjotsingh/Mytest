/* common.h
 *	Common stuff for the as48 assembler
 */

#ifndef COMMON_H
#define COMMON_H

/* symbol table entries are made from these */
struct symbol_type {
  char *str;	/* pointer to the name */
  int type;
  
  struct symbol_type *next;	/* for lists */
  struct symbol_type *previous;
  struct symbol_type *Lchild;	/* for trees */
  struct symbol_type *Rchild;
  
  struct symbol_type *nextlabel;	/* for multiple labels 
					 * or for linking expressions */
  struct symbol_type *nextfield;        /* next expression in a statement */
  int n;				/* The value, for CONST, PC */
  char *qstr;			/* the string if this is a qstring */
  
  int validsymbol;		/* set nonzero when this address is
				   known */
  int visited;			/* set nonzero when a node is being
				   visited in a travesal */
  int refcount;			/* for dealocation */
  int lineno;			/* first encounter */
};

/* each statement in the forest of trees is one of these */
struct node {
  struct node *next;		/* for linking trees */
  int bytes;			/* number of bytes to emit, if
				   0, opcode contains directive */


  int opcode;                   /* for special stuff like dotorg.. */

  unsigned int offset;          /* stow offset for this statement */

  struct symbol_type *fields;   /* list of fields for this statement */
  struct symbol_type *label;	/* pointer to a label associated
				   with this statement */
  int line;			/* line where this came from */
};

struct field {

  struct field *next;           /* link to next field */
  struct symbol_type *name;     /* name of this field */
  struct symbol_type *expr;     /* expression that calculates the size of this
				 * field in bits */
  unsigned int size;            /* stow size of field here, after pass 2 */
};

/* Function declarations */
struct symbol_type *symbol(char *str);
int eval(struct symbol_type *expression);
const char *tokenstring(int token);

/* global variables */
/* parser.y */
extern struct node *root;
extern struct field *fields;
extern struct symbol_type *module_name; /* module name */
/* main.c */
extern char *asmfile;

/* Flex stuff */
int yyerror(char *msg);
int yywrap();
extern int lineno;
extern char linebuf[];	/* for storing the line that is being parsed */

/* bison stuff */
extern int yydebug;
int yyparse();
int yylex();
#endif /* COMMON_H */


