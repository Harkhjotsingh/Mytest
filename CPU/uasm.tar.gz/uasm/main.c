/* main.c
 *	The program that drives the parser.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "parser.tab.h"
#include "common.h"

/* function prototypes */
void dolabels(int pass);
void spewcode(FILE *fp,FILE *listing);
void spewcodevhdl(FILE *fp);
void printbin(FILE *fp,int n, int size);
void printstmt(FILE *fp, struct node *stmt);
char *checkext(char *s,char *e);

int dashl=0,dashp=0;
char *asmfile;

struct field *fields = NULL;  /* List of all the defined fields */
unsigned int number_of_fields=0; /* count of the number of defined fields */


unsigned int code_size;

int main(int argc, char *argv[]) {
  FILE *fin,*fout;
  FILE *listing;
  char *p;
  char objfile[100];
  char objvhdlfile[100];
  char lstfile[100];

  if( argc < 2 ) {
    fprintf(stderr,"Usage: %s infile.asm\n",
	    argv[0]);
    exit(1);
  }

  if( argc != 2) {
    fprintf(stderr,"Missing input file.\n");
    exit(1);
  }

  asmfile = argv[1];

  if( (p=checkext(asmfile,".asm")) == NULL ) {
    fprintf(stderr,"Input file \"%s\" must end with .asm\n",
	    asmfile);
    exit(1);
  }

  if( (fin = freopen(asmfile,"r",stdin)) == NULL ) {
    fprintf(stderr,"Cannot open input file: \"%s\"\n",asmfile);
    exit(1);
  }

  strcpy(objfile,asmfile);
  strcpy(objfile+(p-asmfile),".v");

  strcpy(objvhdlfile,asmfile);
  strcpy(objvhdlfile+(p-asmfile),".vhdl");

  strcpy(lstfile,asmfile);
  strcpy(lstfile+(p-asmfile),".lst");

  listing = fopen(lstfile,"w");
  if(listing == NULL) {
    fprintf(stderr,"Cannot open listing file: \"%s\"\n",lstfile);
    exit(1);
  }

  yydebug = 0;
  yyparse();		/* parse the input */

	/*    for(stmt = root; stmt; stmt = stmt->next) {
	      printf("opcode: %02X,  bytes:%d\n",stmt->opcode, stmt->bytes);
	      }*/
	
  fflush(stdout);
  dolabels(1);	/* Figure out the labels */
  dolabels(2);	/* and now do the eqates */

/*    for(stmt = root; stmt; stmt = stmt->next) {
	if(stmt->label) {
	    printf("Label: %s, value %X, validsymbol:%d\n",
		stmt->label->str, stmt->label->n, stmt->label->validsymbol);
	}
    }*/

  fout = fopen(objfile,"w");
  if(fout == NULL) {
    fprintf(stderr,"Cannot open verilog output file: \"%s\"\n",objfile);
    exit(1);
  }

  spewcode(fout,listing);	   /* output the object file */
  fclose(fout);
  fclose(listing);

  fout = fopen(objvhdlfile,"w");
  if(fout == NULL) {
    fprintf(stderr,"Cannot open VHDL output file: \"%s\"\n",objvhdlfile);
    exit(1);
  }
  spewcodevhdl(fout);	   /* output the object file */
  fclose(fout);


  return 0;
}

/* walk though the forest of trees and figure out all the addreses */
/* if it is the second pass, also figure out the equates */
void dolabels(int pass) {
  struct node *stmt;
  struct field *field;
  struct symbol_type *sym;
  int temp;
  unsigned int offset = 0;

  /* Walk over the statements */
  for(stmt = root; stmt != NULL; stmt = stmt->next)
    {
      /* work out fields in the chunk */
      if(stmt->label) { /* there is a label for this line */
	for(sym = stmt->label; sym != NULL; sym = sym->nextlabel)
	  {
	    sym->n = offset;
	    sym->validsymbol = 1;	/* and it is valid now */
	  }
      }
	  
      /* figure out offsets for each of the individual statements */


      switch(stmt->opcode) {
      case DOTORG:
	offset = eval(stmt->fields);

      case DOTEQU: case DOTSET:
	if(pass == 2) {
	  temp = eval(stmt->fields);
	  if(stmt->label) { /* there is a label for this line */
	    for(sym = stmt->label; sym; sym = sym->nextlabel) {
	      sym->n = temp;
	      sym->validsymbol = 1;	/* and it is valid now */
	    }
	  }
	}
	break;
	    
	/* create fields on the first passs */
      case DOTFIELD:
	if(pass == 1) {
	  struct field *p;
	  /* Create a new field for the list */
	  field = (struct field *)malloc(sizeof(*field));
	  field->next = NULL;
	  field->name = stmt->label;
	  field->expr = stmt->fields;

	  if(fields == NULL) {
	    fields = field;
	  } else {
	    /* Find the end of the list and append the new field */
	    for(p=fields; p->next != NULL; p=p->next);
	    
	    p->next = field;
	  }
	  number_of_fields++;
	}

      case DOTEND: case DOTMODULE: 
	break;
	    
      }

      stmt->offset = offset;
      /* update offset */
      offset += stmt->bytes;

      /* update maximum address */
      if(offset > code_size) code_size = offset;

    }

  /* if this is pass 2 also figure out all the field widths */
  if(pass == 2) {
    for(field = fields; field!=NULL; field=field->next) {
      field->size = eval(field->expr);
    }
  }

  /* Adjust code size to match reality */
  code_size--;


}

/* output the code */
void spewcode(FILE *fp, FILE *listing)
{
  time_t the_time;
  struct node *stmt;
  struct symbol_type *p;
  struct field *f;
  unsigned int data_width=0;
  unsigned int addr_width=0;
  unsigned int field=0;
  unsigned int i;
  char *module;
  

  /* compute the size of the address bus needed */
  i = code_size;
  addr_width = 0;
  while(i != 0) {
    i = i/2;
    addr_width++;
  }

  /* Output the time and date the file was generated */
  the_time=time(NULL); /* Fetch the current time */
  fprintf(fp,"/*\n"
	  " * DO NOT EDIT THIS FILE, your changes will be overwritten\n"
	  " * This is an automatically generated file.\n"
	  " * It was generated with uasm, the microassembler, on\n"
	  " * %s"
	  " */\n\n",
	  ctime(&the_time));

  fprintf(fp,
	  "/*\n"
	  " * This case statement was generated with the following\n"
	  " *   fields:\n"
	  "\n");

  /* dump out the fields, and calculate the data width */
  data_width = 0;
  for(f=fields; f!=NULL; f=f->next)
    data_width += f->size;

  field = data_width-1;   /* `-1' because the LSB is `0' */

  /* Output a wire wide enough to hold the data */
  fprintf(fp,"   wire [%2u:0]  DATA_out;\n",
	  field);

  for(f=fields; f!=NULL; f=f->next) {
    fprintf(fp,"   wire ");
    if(f->size > 1)
      fprintf(fp,"[%2u:0]  %s;\n", f->size-1, f->name->str);
    else
      fprintf(fp,"        %s;\n",f->name->str);

    field -= f->size;
  }

  fprintf(fp,"\n\n");
  field = data_width-1;   /* `-1' because the LSB is `0' */
  for(f=fields; f!=NULL; f=f->next) {
    fprintf(fp,"   assign %20s = ", f->name->str);
    if(f->size > 1)
      fprintf(fp,"DATA_out[%2u:%2u];", field, field - f->size+1);
    else
      fprintf(fp,"DATA_out[%2u];   ", field);

    fprintf(fp, "    // bit size:%u\n",f->size);

    field -= f->size;
  }
  fprintf(fp,
	  " *\n"
	  " * Yeilding a total data width of %u bits for %u fields.\n"
	  " * The maximum address encountered was 0x%x, needing %u bits\n"
	  " */\n", data_width, number_of_fields,
	  code_size, addr_width);

  if(module_name != NULL)
    module = module_name->qstr;
  else
    module = "MICROCODE_ROM";

  /* Output the header */
  fprintf(fp,"`timescale 1ns/1ns\n"
	  "module %s (ADDR_in,DATA_out);\n"
	  "   input  [%2d:0] ADDR_in;\n"
	  "   output [%2d:0] DATA_out;\n"
	  "\n"
	  "   reg    [%2d:0] DATA_out_r;\n"
	  "\n",module, addr_width-1,data_width-1,data_width-1);

  /* Output the meat of the statements */
  fprintf(fp,
	  "   assign DATA_out = DATA_out_r;\n"
	  "   always @(ADDR_in)\n"
	  "     begin\n"
	  "        case(ADDR_in)\n");
  for(stmt = root; stmt; stmt = stmt->next) {
    /* If this statement has a label, print it for reference, but just
     * the first one. */
    lineno = stmt->line;
    printstmt(listing,stmt);  /* Dump the statement to the listing file */


    if((stmt->label != NULL) && 
       (stmt->opcode != DOTEQU) && (stmt->opcode != DOTSET)
       && (stmt->opcode != DOTFIELD))
      fprintf(fp,"          /* %s: */\n",stmt->label->str);

    if(stmt->opcode != EXPRLIST) continue;

    if(stmt->bytes != 0) {
      fprintf(fp,

	      "          %d'h%x: DATA_out_r = %d'b",
	      addr_width, stmt->offset, data_width);
      /* Print out the fields in binary */
      f = fields;
      i = 0;
      for(p=stmt->fields; p!=NULL; p=p->nextfield) {
	if(f == NULL) {
	  fprintf(stderr,"%s:%d:Warning too many fields, expecting %u, "
		  "but got %u.\n",
		  asmfile,lineno, number_of_fields, i+1);
	  continue;
	}
	printbin(fp,eval(p),f->size);
	if(p->nextfield != NULL) fprintf(fp,"_");
	f = f->next;
	i++;
      }
      if(f != NULL) {
	fprintf(stderr,"%s:%d:Warning too few fields, expecting %u, "
		"but got %u.\n",
		asmfile, lineno, number_of_fields, i);

      }

      fprintf(fp,";\n");

    }

  }
  fprintf(fp,
	  "          default: DATA_out_r = %d'b0;\n"
	  "       endcase\n"
	  "     end\n"
	  "endmodule\n",data_width);


}

/* output the code */
void spewcodevhdl(FILE *fp)
{
  time_t the_time;
  struct node *stmt;
  struct symbol_type *p;
  struct field *f;
  unsigned int data_width=0;
  unsigned int addr_width=0;
  unsigned int field=0;
  unsigned int i;
  char *module;
  

  /* compute the size of the address bus needed */
  i = code_size;
  addr_width = 0;
  while(i != 0) {
    i = i/2;
    addr_width++;
  }

  if(module_name != NULL)
    module = module_name->qstr;
  else
    module = "MICROCODE_ROM";

  data_width = 0;
  for(f=fields; f!=NULL; f=f->next)
    data_width += f->size;
  field = data_width-1;   /* `-1' because the LSB is `0' */

  /* Output the time and date the file was generated */
  the_time=time(NULL); /* Fetch the current time */
  fprintf(fp,"--\n"
	  "-- DO NOT EDIT THIS FILE, your changes will be overwritten\n"
	  "-- This is an automatically generated file.\n"
	  "-- It was generated with uasm, the microassembler, on\n"
	  "-- %s"
	  "--\n"
	  "--\n",
	  ctime(&the_time));
  fprintf(fp,
	  "-- component %s\n"
	  "--   port( ADDR_IN  : in  std_logic_vector(%2d downto 0);\n"
	  "--         DATA_OUT : out std_logic_vector(%2d downto 0));\n"
	  "-- end component;\n"
	  "--\n",module, addr_width-1,data_width-1);

  fprintf(fp,
	  "--\n"
	  "-- This case statement was generated with the following\n"
	  "--   fields:\n"
	  "--\n"
	  "--  signal     DATA_OUT : std_logic_vector(%2u downto 0);\n",
	  field);

  /* dump out the fields, and calculate the data width */
  for(f=fields; f!=NULL; f=f->next) {
    fprintf(fp,"--  signal ");
    if(f->size > 1)
      fprintf(fp,"%12s : std_logic_vector(%2u downto 0);\n", 
	      f->name->str,f->size-1);
    else
      fprintf(fp,"%12s : std_logic;\n",f->name->str);

    field -= f->size;
  }

  fprintf(fp,"--\n--\n");

  field = data_width-1;   /* `-1' because the LSB is `0' */
  for(f=fields; f!=NULL; f=f->next) {
    fprintf(fp,"--   %18s <= ", f->name->str);
    if(f->size > 1)
      fprintf(fp,"DATA_OUT(%2u downto %2u);", field, field - f->size+1);
    else
      fprintf(fp,"DATA_OUT(%2u);          ", field);

    fprintf(fp, "   -- bit size: %u\n",f->size);

    field -= f->size;
  }
  fprintf(fp,
	  "--\n"
	  "-- Yeilding a total data width of %u bits for %u fields.\n"
	  "-- The maximum address encountered was 0x%x, needing %u bits\n"
	  "--\n", data_width, number_of_fields,
	  code_size, addr_width);

  /* Output the header */
  fprintf(fp,"library ieee;\n"
	  "use ieee.std_logic_1164.ALL;\n"
	  "\n"
	  "entity %s is\n"
	  "port( ADDR_IN  : in  std_logic_vector(%2d downto 0);\n"
	  "      DATA_OUT : out std_logic_vector(%2d downto 0));\n"
	  "end %s;\n"
	  "\n",module, addr_width-1,data_width-1, module);

  /* Output the meat of the statements */
  fprintf(fp,
	  "architecture RTL of %s is\n"
	  "\n"
	  "   signal DATA_OUT_R : std_logic_vector(%d downto 0);\n"
	  "begin\n"
	  "   DATA_OUT <= DATA_OUT_R;\n"
	  "\n"
	  "   process(ADDR_IN)\n"
	  "     begin\n"
	  "        case ADDR_IN is\n",module, data_width-1);
  for(stmt = root; stmt; stmt = stmt->next) {
    /* If this statement has a label, print it for reference, but just
     * the first one. */
    lineno = stmt->line;


    if((stmt->label != NULL) && 
       (stmt->opcode != DOTEQU) && (stmt->opcode != DOTSET)
       && (stmt->opcode != DOTFIELD))
      fprintf(fp,"          -- %s:\n",stmt->label->str);

    if(stmt->opcode != EXPRLIST) continue;

    if(stmt->bytes != 0) {
      fprintf(fp,
	      "          when \"");
      printbin(fp,stmt->offset,addr_width);

      fprintf(fp,
	      "\" => DATA_OUT_R <= \"");
      /* Print out the fields in binary */
      f = fields;
      i = 0;
      for(p=stmt->fields; p!=NULL; p=p->nextfield) {
	if(f == NULL) {
	  fprintf(stderr,"%s:%d:Warning too many fields, expecting %u, "
		  "but got %u.\n",
		  asmfile,lineno, number_of_fields, i+1);
	  continue;
	}
	printbin(fp,eval(p),f->size);
	f = f->next;
	i++;
      }
      if(f != NULL) {
	fprintf(stderr,"%s:%d:Warning too few fields, expecting %u, "
		"but got %u.\n",
		asmfile, lineno, number_of_fields, i);

      }

      fprintf(fp,"\";\n");

    }

  }
  fprintf(fp,
	  "          when others => DATA_OUT_R <= \"");
  printbin(fp,0,data_width);
  fprintf(fp,"\";\n"
	  "       end case;\n"
	  "     end process;\n"
	  "end RTL;\n");

}

/* print the requested number in binary */
void printbin(FILE *fp,int n, int size)
{
  char *buffer, *p;
  int i;

  /* obtain a buffer */
  buffer = alloca(size + 1);
  /* fill it with bits and a null */
  buffer[size] = 0;
  p = &buffer[size-1];
  for(i=size; i>0; i--) {
    *p-- = n & 1 ? '1' : '0';
    n = n / 2;
  }
  
  fprintf(fp,"%s",buffer);

}

/* Print the statement pointed to by stmt to the supplied file pointer
 * try to pretty print the fields.
 */
void printstmt(FILE *fp,struct node *stmt)
{
  struct symbol_type *p;

  fprintf(fp,"L%04u %04X ",stmt->line,stmt->offset);
  
  /* print any labels */
  if(stmt->label != NULL)
    {
      for(p=stmt->label; p!=NULL; p=p->nextlabel) {
	fprintf(fp,"%15s: ",p->str);
	if(p->nextlabel != NULL) fprintf(fp,"\n     ");
      }
    }
  else
    fprintf(fp,"                 ");

  /* Print out any opcodes for the statment if they exist */
  switch(stmt->opcode) {
  case DOTORG: case DOTEQU: case DOTSET: case DOTEND:
  case DOTFIELD:
    fprintf(fp,"%s ",
	    tokenstring(stmt->opcode));
    if(stmt->fields != NULL)
      fprintf(fp,"%d",eval(stmt->fields));
    break;

  case DOTMODULE:
    fprintf(fp,"%s \"%s\"",
	    tokenstring(stmt->opcode),
	    stmt->fields->qstr);
    break;

  default:
    /* this is a list of fields */
    for(p=stmt->fields; p!=NULL; p=p->nextfield) {
      fprintf(fp,"%d ",eval(p));
      if(p->nextfield != NULL) fprintf(fp,"\\ ");
    }
    break;
  }
  fprintf(fp," ;\n");

}



/* ----------------------------------------------------------------------
 * checkext:
 *	Check the string s, for the presence of an extenstion e.
 *	Return the position of the start of e in s.
 *	or return NULL.
 */

char *checkext(char *s,char *e)
{
	register char *ps = s, *pe = e;

	while( *ps ) ps++;
	while( *pe ) pe++;

	for( ; ps>=s && pe>=e && *ps == *pe; ps--, pe-- )
		if( pe == e ) return(ps);
	return(NULL);
}

